use [Automationnew]
GO
/****** Object:  Table [dbo].[America]    Script Date: 8/23/2016 3:19:35 PM ******/
CREATE TABLE [dbo].[Exercise2](
	[Yer] [varchar](max) NULL,
	[PolicyPrice] [varchar](max) NULL,
	[DefactoRating] [varchar](max) NULL,
	[MaxDays] [varchar](max) NULL,
	[MaxExcess] [varchar](max) NULL,
	[Medical] [varchar](max) NULL,
	[Cancellation] [varchar](max) NULL,
	[Baggage] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]