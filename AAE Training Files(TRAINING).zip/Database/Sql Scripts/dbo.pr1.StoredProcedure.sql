use [Automationnew]
GO
/****** Object:  StoredProcedure [dbo].[pr1]    Script Date: 8/23/2016 3:19:35 PM ******/
CREATE procedure [dbo].[pr1]
as
select * from dbo.Automation
GO
