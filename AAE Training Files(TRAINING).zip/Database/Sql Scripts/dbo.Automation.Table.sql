use [Automationnew]
GO
/****** Object:  Table [dbo].[Automation]    Script Date: 8/23/2016 3:19:35 PM ******/
CREATE TABLE [dbo].[Automation](
	[Name] [char](10) NULL,
	[Age] [smallint] NULL
) ON [PRIMARY]
