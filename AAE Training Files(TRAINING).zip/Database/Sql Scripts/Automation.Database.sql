USE [master]
GO
/****** Object:  Database [Automationnew]    Script Date: 8/23/2016 3:19:35 PM ******/
CREATE DATABASE [Automationnew]
 
